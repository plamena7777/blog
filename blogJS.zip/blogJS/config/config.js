const path = require('path');

module.exports = {
    rootFolder: path.normalize(path.join(__dirname, '/../'))
};