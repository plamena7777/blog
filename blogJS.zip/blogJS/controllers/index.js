const user = require('./user');
const article = require('./article');
const home = require('./home');

module.exports = {
    user,
    article,
    home
};